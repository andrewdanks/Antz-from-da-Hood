import Ants
import Bot

main :: IO()
main = game doTurn
